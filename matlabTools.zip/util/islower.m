function answer = islower(s)
%% Return true iff the input string is all lower case
answer = strcmp(s, lower(s)); 

end