function answer = islower(s)
%% Return true iff the input string is all lower case

% This file is from matlabtools.googlecode.com

answer = strcmp(s, lower(s)); 

end
