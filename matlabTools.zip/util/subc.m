function a = subc(b,ndx)
% Subscript the cell array return value of a function directly

% This file is from matlabtools.googlecode.com

a = b{ndx};

end
