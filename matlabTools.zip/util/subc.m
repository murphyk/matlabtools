function a = subc(b,ndx)
% Subscript the cell array return value of a function directly
a = b{ndx};

end