function B = repmatC(varargin)
%% A c version of repmat
%PMTKmex

% This file is from matlabtools.googlecode.com

   B = repmat(varargin{:}); 
end
