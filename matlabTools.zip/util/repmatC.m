function B = repmatC(varargin)
%% A c version of repmat
%PMTKmex
   B = repmat(varargin{:}); 
end