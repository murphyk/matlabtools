function answer = isupper(s)
%% Return true iff the input string is all upper case
answer = strcmp(s, upper(s)); 

end