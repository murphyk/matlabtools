function C = insertEnd(element, C)
% Add an element to the end of a cell array

% This file is from matlabtools.googlecode.com

C{end+1} = element;
end
