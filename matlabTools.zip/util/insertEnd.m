function C = insertEnd(element, C)
% Add an element to the end of a cell array
C{end+1} = element;
end