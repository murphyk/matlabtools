function b = iseven(a)
% Return true iff the input is an even integer

% This file is from matlabtools.googlecode.com

b = mod(a, 2) == 0;

end
