function b = iseven(a)
% Return true iff the input is an even integer
b = mod(a, 2) == 0;

end