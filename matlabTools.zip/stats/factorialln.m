function L = factorialln(n)
% L(i) = log n(i)!

% This file is from matlabtools.googlecode.com


% n! = gamma(n+1)
L= gammaln(n + 1);
end
