#!/usr/bin/perl
# simple script used to test if perl is installed. 
print 1